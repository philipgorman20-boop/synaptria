/** Public application-layer exports for the Organization module. */
export const organizationModule = 'organization' as const;
