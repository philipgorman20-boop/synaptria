import type { AuditEvent as PrismaAuditEvent, PrismaClient } from '@prisma/client';
import type { AuditEventRecord, AuditRepository, RecordAuditEventInput } from '@synaptria/audit';
import { identifier, type OrganizationId, type RequestId, type CorrelationId, type UserId } from '@synaptria/core';

import { toPrismaJson } from '../json';

export type AuditDatabaseClient = Pick<PrismaClient, 'auditEvent'>;

export class PrismaAuditRepository implements AuditRepository {
  constructor(private readonly client: AuditDatabaseClient) {}

  async create(input: RecordAuditEventInput): Promise<AuditEventRecord> {
    const row = await this.client.auditEvent.create({
      data: {
        organizationId: input.organizationId,
        userId: input.actor.userId,
        actorType: input.actor.type,
        actorId: input.actor.id,
        action: input.action,
        entityType: input.target.entityType,
        entityId: input.target.entityId,
        programId: input.target.programId,
        requestId: input.request?.requestId,
        correlationId: input.request?.correlationId,
        ipAddress: input.request?.ipAddress,
        userAgent: input.request?.userAgent,
        before: input.before === undefined ? undefined : toPrismaJson(input.before),
        after: input.after === undefined ? undefined : toPrismaJson(input.after),
        metadata: input.metadata === undefined ? undefined : toPrismaJson(input.metadata),
        occurredAt: input.occurredAt,
      },
    });

    return mapAuditEvent(row);
  }
}

function mapAuditEvent(row: PrismaAuditEvent): AuditEventRecord {
  return {
    id: row.id,
    organizationId: identifier(row.organizationId, 'OrganizationId') as OrganizationId,
    actor: {
      type: row.actorType,
      ...(row.actorId === null ? {} : { id: row.actorId }),
      ...(row.userId === null ? {} : { userId: identifier(row.userId, 'UserId') as UserId }),
    },
    action: row.action,
    target: {
      entityType: row.entityType,
      ...(row.entityId === null ? {} : { entityId: row.entityId }),
      ...(row.programId === null ? {} : { programId: row.programId }),
    },
    ...((row.requestId === null &&
      row.correlationId === null &&
      row.ipAddress === null &&
      row.userAgent === null)
      ? {}
      : {
          request: {
            ...(row.requestId === null
              ? {}
              : { requestId: identifier(row.requestId, 'RequestId') as RequestId }),
            ...(row.correlationId === null
              ? {}
              : { correlationId: identifier(row.correlationId, 'CorrelationId') as CorrelationId }),
            ...(row.ipAddress === null ? {} : { ipAddress: row.ipAddress }),
            ...(row.userAgent === null ? {} : { userAgent: row.userAgent }),
          },
        }),
    ...(row.before === null ? {} : { before: row.before as AuditEventRecord['before'] }),
    ...(row.after === null ? {} : { after: row.after as AuditEventRecord['after'] }),
    ...(row.metadata === null ? {} : { metadata: row.metadata as AuditEventRecord['metadata'] }),
    occurredAt: row.occurredAt,
  };
}
