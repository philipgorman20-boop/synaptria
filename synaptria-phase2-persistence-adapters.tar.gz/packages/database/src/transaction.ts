import type { Prisma, PrismaClient } from '@prisma/client';

import { PrismaAuditRepository } from './audit/prisma-audit-repository';
import { PrismaEventRepository } from './events/prisma-event-repository';

export interface PersistenceRepositories {
  readonly audit: PrismaAuditRepository;
  readonly events: PrismaEventRepository;
}

export function createPersistenceRepositories(
  client: PrismaClient | Prisma.TransactionClient,
): PersistenceRepositories {
  return {
    audit: new PrismaAuditRepository(client),
    events: new PrismaEventRepository(client),
  };
}

export async function withDatabaseTransaction<T>(
  client: PrismaClient,
  operation: (repositories: PersistenceRepositories, transaction: Prisma.TransactionClient) => Promise<T>,
): Promise<T> {
  return client.$transaction(async (transaction) =>
    operation(createPersistenceRepositories(transaction), transaction),
  );
}
